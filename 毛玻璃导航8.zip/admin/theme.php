<?php 
$title = '主题设置';
include './head.php';
function theme($theme,$str){
    $theme_ini = ROOT.'template/'.$theme.'/theme.ini';
    $arr = json_decode(file_get_contents($theme_ini), true);
    if(!empty($arr[$str])){
        return strip_tags($arr[$str]);
    }
    else if($str =='theme_version'){
        return '未知';
    }
    else if($str =='theme_name'){
        return $theme;
    }
    else{
        return false;
    }
}
$set=isset($_GET['set'])?$_GET['set']:null;
if(!empty($set)) {
	if(saveSetting('template',$set)) {
		exit('<script>alert("主题修改成功！");window.location.href="./theme.php";</script>');
	} else {
		exit('<script>alert("主题修改失败！");window.location.href="./theme.php";</script>');
	}
}
?>
    <main class="lyear-layout-content">
  <div class="container-fluid">
		        <div class="row">
		          <div class="col-lg-12">
  <div class="bc_mbl">
        <div class="card-header">	
        
        <a href="./theme.php?mod=template2">模板设置</a>
        
        <div class="d-flex">
        <div class="p-2 w-100"><h3>主题设置</h3> </div> <div class="p-2 flex-shrink-1"> <a class="btn btn-blue" href="https://spage.lylme.com/themes" target="_blank">更多主题 ></div></div></a></div>
        <div class="bc-row card-body bc-space10">
               
<?php 
    $theme_path = ROOT.'template/';
    $themes = glob($theme_path."*", GLOB_ONLYDIR);
    foreach($themes as $theme) {
    	$theme =  str_replace($theme_path ,"" , $theme);
    	echo' <div class="bc-xs6 bc-sm3"><div class="bc_mbl">
    	<div class="d-flex">
        <div class="p-2 w-100"><span>
    	'.theme($theme,"theme_name").' </span></div>
        <div class="p-2 flex-shrink-1"><span class="btn">版本：'.theme($theme,"theme_version").'</span></div>
      </div>';
    	
        echo '';
        if(theme($theme,"theme_jmg")){
    	 echo '<img class="theme_img" src="https://vkceyugu.cdn.bspapp.com/VKCEYUGU-3e301267-ab9e-45d1-93a3-d511af538949/c465debc-1a58-4e43-b9ac-6e4ee0beecb1.jpg">';
    	} else {
        echo '<img class="theme_img" src="'.theme($theme,"theme_img").'">';
        }
    
    	echo '<div class="overflow-auto p-2" style="height: 50px;">'.theme($theme,"theme_explain").'</div>';
    	if(theme($theme,"theme_course")){
    	    echo ' <a href="'.theme($theme,"theme_course").'" target="_blank">主题教程</a>';
    	}
   
    	if($conf['template'] == $theme) {
    		echo '<div class="p-2 d-grid"><p class="p-1 btn btn-default disabled">当前使用</p></div>';
    	} else {
    		echo '<div class="p-2 d-grid"><a href="./theme.php?set='.$theme.'" class="p-1 btn btn-primary">使用</a></div>';
    	}
    	echo '</div>','</div>';
    }
?> 

                              
                </div>
      </div> 
 </div> 
 

 
</main>
<?php 
include './footer.php';
?>