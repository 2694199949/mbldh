<?php
include_once("../include/common.php");
if(isset($islogin)==1) {
} else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title><?php echo $title.' - '.$conf['title'];?></title>
<link rel="icon" href="/assets/img/logo.png" type="image/ico">
<meta name="author" content="yinqi">

<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="stylesheet" type="text/css" href="css/materialdesignicons.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/animate.min.css">
<link rel="stylesheet" type="text/css" href="css/style.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/bc.css">
</head>

<body>
<!--页面loading-->
<div id="lyear-preloader" class="loading">
  <div class="ctn-preloader">
    <div class="round_spinner">
      <div class="spinner"></div>
      <img src="images/loading-logo.png" alt="">
    </div>
  </div>
</div>
<!--页面loading end-->
<div class="lyear-layout-web">
  <div class="lyear-layout-container">
    <!--左侧导航-->
    <aside class="lyear-layout-sidebar">

      <!-- logo -->
      <div id="logo" class="sidebar-header">
        <a href="index.php"><img src="images/logo-sidebar.png" title="LightYear" alt="LightYear" /></a>
      </div>
      <div class="lyear-layout-sidebar-info lyear-scroll">

        <nav class="sidebar-main">

          <ul class="nav-drawer">
            <li class="nav-item <?php echo checkIfActive('index')?>">
              <a href="index.php">
                <i class="mdi mdi-home-city-outline"></i>
                <span>后台首页</span>
              </a>
            </li>
            <li class="nav-item nav-item-has-subnav <?php echo checkIfActive('set,tag,sou,apply,user,theme')?>">
              <a href="javascript:void(0)">
                <i class="mdi mdi-television-guide"></i>
                <span>网站配置</span>
              </a>
              <ul class="nav nav-subnav">
                
                <li class="<?php echo checkIfActive('set')?>"> <a href="./set.php">网站基本设置</a> </li>
                <li class="<?php echo checkIfActive('tag')?>"> <a href="./tag.php">导航菜单设置</a> </li>
                <li class="<?php echo checkIfActive('sou')?>"> <a href="./sou.php">搜索引擎设置</a> </li>
                <li class="nav-item <?php echo checkIfActive('theme')?>"> <a href="./theme.php">网站主题设置</a> </li>
                <li class="nav-item  <?php echo checkIfActive('apply')?>"> <a href="./apply.php">收录管理设置 </a>
<?php $applyrows = $DB->num_rows($DB->query("SELECT * FROM `lylme_apply` WHERE `apply_status` = 0"));
if($applyrows>0) {
	echo'<style> .applyrow{width: 18px;height: 18px;top: 15px;right: 24px;font-size: 10px;font-weight: bold;color: #fff;background-color: red;border-radius: 100%;text-align: center;vertical-align: middle;position: absolute;line-height: 1.5;}</style>
	<div class="applyrow">'.$applyrows.'</div>';
}
?></li>
                <li class="<?php echo checkIfActive('user')?>"> <a href="./user.php">修改账号密码</a> </li>
              </ul>
            </li>
      <?php
if ($conf['dh'] != 'false') {
echo '            <li class="nav-item nav-item-has-subnav '.checkIfActive('group,link,pwd').'">
              <a href="javascript:void(0)">
                <i class="mdi mdi-link"></i>
                <span>导航管理</span>
              </a>
              <ul class="nav nav-subnav">
              
            <li class="nav-item '.checkIfActive('group').' "> <a href="./group.php">分组管理</a></li>
            <li class="nav-item '.checkIfActive('link').'"> <a href="./link.php">链接管理</a></li>
            <li class="nav-item '.checkIfActive('pwd').'"> <a href="./pwd.php">加密管理</a></li>

          </ul>
          </li>';
}
else {

    echo 
include "list.php";

}
?>

            <li class="nav-item <?php echo checkIfActive('update')?>"> <a href="./update.php"><i class="mdi mdi-update"></i>检查更新</a> </li>
            <li> <a href="javascript:loginout()"><i class="mdi mdi-logout"></i> 退出登录</a> </li>
        </nav>

        <div class="sidebar-footer">
          <p class="copyright">
            <span>Copyright &copy; 2023. </span>
            <a target="_blank" href="">白菜吖</a>
            <span> All rights reserved.</span>
          </p>
        </div>
      </div>

    </aside>
    <!--End 左侧导航-->

    <!--头部信息-->
    <header class="lyear-layout-header">

      <nav class="navbar">

        <div class="navbar-left">
          <div class="lyear-aside-toggler">
            <span class="lyear-toggler-bar"></span>
            <span class="lyear-toggler-bar"></span>
            <span class="lyear-toggler-bar"></span>
          </div>
        </div>

        <ul class="navbar-right d-flex align-items-center">
        毛玻璃引导页/导航系统
        </ul>

      </nav>

    </header>
    <!--End 头部信息-->
