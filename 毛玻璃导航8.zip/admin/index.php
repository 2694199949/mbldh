<?php 
$title = '后台管理';
include './head.php';
$last = date("Ymd");
if(@file_get_contents('log.txt') != $last || !file_exists('cache.php')){
$update = update();
file_put_contents('log.txt',$last);
var_export($update,true);
$content = "<?php\nreturn ".var_export($update,true)."\n?>";
file_put_contents('cache.php', $content);
}
$mysqlversion=$DB->count("select VERSION()");
function tjsj($tjname) {
	if($tjname=='') {
		echo '0';
	} else {
		echo $tjname;
	}
}

?>
   <!--页面主要内容-->
    <main class="lyear-layout-content">
      <div class="container-fluid">
        <div class="row">
<?php 
$update  = require('cache.php');
if(!empty($update)) {
	if($update['switch']) {
		if($update['msg_switch'] && !empty($update['msg'])) {
			echo '
          <div class="bc-xs12 bc-sm12 bc-lg12"><div class="bc_mbl"><div class="card-header"><h4>'.$update['title'].'</h4></div><ul class="list-group-bc card-body">'.$update['msg'].'</ul></div></div>';
		}
		if(getver($update['version']) > getver($conf['version'])) {
		    	echo '
          <div class="bc-xs12 bc-sm12 bc-lg12"><div class="bc_mbl"><div class="card-header"><h4>更新提示</h4></div><ul class="list-group-bc card-body">'.$update['update_msg'].'</ul></div></div>';
		}
	}
}
?>
</div>
<div class="row">

          <div class="bc-xs6 bc-sm3 bc-lg3">
            <div class="bc_mbl text-white">
              <div class="card-body">
                <div class="d-flex justify-content-between">
                  <span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
                    <i class="mdi mdi-web fs-4"></i>
                  </span>
                  <span class="fs-1"><?php tjsj($linksrows);
?></span>
                </div>
                <div class="text-end">链接数量</div>
              </div>
            </div>
          </div>
                    
          <div class="bc-xs6 bc-sm3 bc-lg3">
            <div class="bc_mbl text-white">
              <div class="card-body">
                <div class="d-flex justify-content-between">
                  <span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
                    <i class="mdi mdi-account-plus fs-4"></i>
                  </span>
                  <span class="fs-1"><?php tjsj($tjtoday);
?></span>
                </div>
                <div class="text-end">今日浏览量</div>
              </div>
            </div>
          </div>
          
          <div class="bc-xs6 bc-sm3 bc-lg3">
            <div class="bc_mbl text-white">
              <div class="card-body">
                <div class="d-flex justify-content-between">
                  <span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
                    <i class="mdi mdi-account-convert fs-4"></i>
                  </span>
                  <span class="fs-1"><?php tjsj($tjyesterday);
?></span>
                </div>
                <div class="text-end">昨日浏览量</div>
              </div>
            </div>
          </div>

          <div class="bc-xs6 bc-sm3 bc-lg3">
            <div class="bc_mbl text-white">
              <div class="card-body">
                <div class="d-flex justify-content-between">
                  <span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
                    <i class="mdi mdi-account-multiple fs-4"></i>
                  </span>
                  <span class="fs-1"><?php tjsj($tjtotal);
?></span>
                </div>
                <div class="text-end">累计浏览量</div>
              </div>
            </div>
          </div>
<?php
if($applyrows>0) {
	echo'
        <div class="row">   
        <div class="bc-xs6 bc-sm3 bc-lg3">
            <div class="bc_mbl">
              <div class="card-body clearfix">
              <a href="./apply.php">  <div class="pull-right">
                  <p class="h6 bc_white m-t-0">待审核链接</p>
                  <p class="h3 bc_white m-b-0 fa-1-5x">'.$applyrows.'</p>
                </div></a>
                <div class="pull-left"> <span class="img-avatar img-avatar-48 bg-translucent"><i class="mdi mdi-link fa-1-5x"></i></span> </div>
              </div>
            </div>
          </div>
          </div>';
}
?>
           
               <div class="bc-xs12 bc-sm6 bc-lg6">
            <div class="bc_mbl">
              <div class="card-header">
                <h4>仪表盘柱状统计图</h4>
              </div>
              <div class="card-body">
                <canvas class="js-chartjs-bars"></canvas>
              </div>
            </div>
          </div>
          <div class="bc-xs12 bc-sm6 bc-lg6">
            <div class="bc_mbl">
              <div class="card-header">
                <h4>仪表盘折线统计图</h4>
              </div>
              <div class="card-body">
                <canvas class="js-chartjs-lines"></canvas>
              </div>
            </div>
         
        </div>
        
          <div class="bc-xs12 bc-sm12 bc-lg12">
<div class="bc_mbl">
<div class="card-header">
<h4>服务器信息</h4>
	</div>
	<div class="card-body">
		<li class="list-group-bc">
			<b>PHP 版本：</b><?php echo phpversion() ?>
			<?php if(ini_get('safe_mode')) {
	echo '线程安全';
} else {
	echo '非线程安全';
}
?>
		</li>
		<li class="list-group-bc">
			<b>MySQL 版本：</b><?php echo $mysqlversion ?>
		</li>
		
		<li class="list-group-bc">
			<b>服务器软件：</b><?php echo $_SERVER['SERVER_SOFTWARE'] ?>
		</li>
		<li class="list-group-bc">
			<b>程序名称：</b>毛玻璃引导页/导航系统
		</li>
			<li class="list-group-bc">
			<b>建站日期：</b><?php echo $conf['build']?>
		</li>
		<li class="list-group-bc">
			<b>当前版本：</b><?php echo $conf['version']?> <a href="./update.php" target="_blant">检查更新</a>
		</li>
		<li class="list-group-bc">
			<b>最新版本：</b> <?php echo $update['version']?>
		</li>
	</div>
</div>
</div>
    </main>
    <!--End 页面主要内容-->
  </div>
</div>
<?php 
include './footer.php';
?>
<!--图表插件-->
<script type="text/javascript" src="js/Chart.js"></script>
<script type="text/javascript">
$(document).ready(function(e) {
	var $dashChartBarsCnt  = jQuery( '.js-chartjs-bars' )[0].getContext( '2d' ),
	        $dashChartLinesCnt = jQuery( '.js-chartjs-lines' )[0].getContext( '2d' );
	var $dashChartBarsData = {
		labels: ['今日浏览', '昨日浏览', '本月浏览', '总浏览', '链接数', '分组数'],
				datasets: [ {
			label: '数量',
			                borderWidth: 1,
			                borderColor: 'rgba(0,0,0,0)',
							backgroundColor: 'rgba(51,202,185,0.5)',
			                hoverBackgroundColor: "rgba(51,202,185,0.7)",
			                hoverBorderColor: "rgba(0,0,0,0)",
							data: [<?php echo $tjtoday;
			?>, <?php echo $tjyesterday;
			?>, <?php echo $tjmonth;
			?>, <?php echo $tjtotal;
			?>, <?php echo $linksrows;
			?>, <?php echo $groupsrows;
			?>]
		}
		]
	}
	;
	var $dashChartLinesData = {
		labels: ['今日浏览', '昨日浏览', '本月浏览', '总浏览', '链接数', '分组数'],
				datasets: [ {
			label: '数量',
							data: [<?php echo $tjtoday;
			?>, <?php echo $tjyesterday;
			?>, <?php echo $tjmonth;
			?>, <?php echo $tjtotal;
			?>,<?php echo $linksrows;
			?>, <?php echo $groupsrows;
			?>],
							borderColor: '#358ed7',
							backgroundColor: 'rgba(53, 142, 215, 0.175)',
			                borderWidth: 1,
			                fill: false,
			                lineTension: 0
		}
		]
	}
	;
	new Chart($dashChartBarsCnt, {
		type: 'bar',
		        data: $dashChartBarsData
	}
	);
	var myLineChart = new Chart($dashChartLinesCnt, {
		type: 'line',
		        data: $dashChartLinesData,
	}
	);
}
);
</script>