<?php
return array (
  'switch' => true,
  'title' => '官方公告',
  'msg' => '毛玻璃导航/引导单页双系统项目正式上线',
  'msg_switch' => true,
  'version' => 'v1.6.0',
  'update_msg' => '更新说明',
  'update_log' => '<div class=\'callout callout-success\'>更新日志</div>',
  'file' => 'https://cdn.lylme.com/lylme_spage/releases/lylme_spage-update_v1.5.1.zip',
)
?>