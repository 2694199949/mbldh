<?php
define('VERSION', '1.6.0');
?>