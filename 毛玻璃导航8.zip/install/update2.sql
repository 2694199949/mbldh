INSERT INTO `lylme_config` (`k`, `v`, `description`) VALUES
('apply_gg', '<b>收录说明：</b><br>1. 禁止提交违规违法站点<br>2. 页面整洁，无多个弹窗广告和恶意跳转<br>3. 非盈利性网站，网站正常访问<br>4. 添加本站友链或网站已ICP备案优先收录<br>', '收录公告'),
('wap_background', '/assets/img/wapbackground.jpg', '手机端背景');