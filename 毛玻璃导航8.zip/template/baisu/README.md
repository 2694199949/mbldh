# 六零导航页baisu主题
六零导航页(LyLme Spage)`baisu`主题，基于[baisuTwo](https://gitee.com/LyLme/baisu-two)开发

## 注意

**该项目为主题模板文件，不支持直接使用，请前往[LyLme_Spage](https://gitee.com/LyLme/lylme_spage)载安装完整项目源码搭建**

## 截图

**baisu主题PC端截图**

![六零导航页baisuTwo主题PC端截图](https://cdn.lylme.com/img/lylme_spage/image-20220501192454699.png)

![六零导航页baisuTwo主题PC端截图2](https://cdn.lylme.com/img/lylme_spage/image-20220501225604644.png)

**baisu主题手机端截图**

![六零导航页baisuTwo主题手机端截图](https://cdn.lylme.com/img/lylme_spage/image-20220501192631560.png)

![六零导航页baisuTwo主题手机端截图2](https://cdn.lylme.com/img/lylme_spage/image-20220501225251579.png)

## 天气插件

天气插件采用的是【和风天气】的标准版天气插件，可无限制免费试用，需要先注册和风天气账号，
[和风天气账号注册](https://id.qweather.com/#/register)；
[和风天气创建插件页面](https://widget.qweather.com/create-standard)
插件 选择【横版】、【款：240px】、【高:180px】;否则会出现样式偏移的问题。其他条件任选。
生成代码后  除第一行`<div id="he-plugin-standard"></div>`外，其他代码复制到主题文件夹下`index.php`底部对应位置即可。

## 相关链接

* [OneNav官网](https://nav.rss.ink/)
* [onenav作者](https://www.xiaoz.me/)
*  [baisuTwo](https://gitee.com/LyLme/baisu-two)
* [LyLme_Spage](https://gitee.com/LyLme/lylme_spage)