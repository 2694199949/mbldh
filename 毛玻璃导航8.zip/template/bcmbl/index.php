<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>HTML</title>
  <!-- HTML -->
  <!-- Custom Styles -->
  <link rel="stylesheet" href="<?php echo $templatepath;?>/style.css">
  <link rel="stylesheet" href="<?php echo $templatepath;?>/bc.css">

<body>
  <div class="bc_content">
    <div class="bc-fluid">
      <div class="bc-row bc-space10">
        <div class="bc-xs12 bc-sm6 bc-md6 bc-lg6">
          <div class="bc_mbl bc_box" id="bc_mobile_head">
            <div class="bc-row">
              <div class="bc-xs3">
                <img class="bc_mbl bc_box img-avatar " style="border-radius: 50%;" src="//q4.qlogo.cn/headimg_dl?dst_uin=2694199949&spec=100">
              </div>
              <div class="bc-xs9">
                <div class="bc-xs12">
                  <div id="bc_name">白菜吖</div>
                  <div id="bc_tip">Tips：相信技术，传递价值！</div>
                </div>
                <div class="bc-xs12">
                  <a class="btn">标签：</a>
                  <a class="btn btn-orange">社牛</a>
                  <a class="btn btn-purple">野王</a>
                  <a class="btn btn-green">可达鸭</a>
                  <a class="btn btn-blue">ฅ՞•ﻌ•՞ฅ</a>
                </div>
                <div class="bc-xs12">
                  <a class="btn">擅长：</a>
                  <a class="btn btn-green">JavaScript</a>
                  <a class="btn btn-yellow">html/css</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="bc-xs4 bc-sm2 bc-md2 bc-lg2">
          <div class="bc_box bc_mbl bc_center">
            <svg class="icon" aria-hidden="true">
              <use xlink:href="#icon-weixin"></use>
            </svg>
            Tx_xbc</div>
        </div>
        <div class="bc-xs5 bc-sm2 bc-md2 bc-lg2">
          <div class="bc_box bc_mbl bc_center">
            <svg class="icon" aria-hidden="true">
              <use xlink:href="#icon-QQ"></use>
            </svg>
            2694199949</div>
        </div>
        <div class="bc-xs3 bc-sm2 bc-md2 bc-lg2">
          <div class="bc_box bc_mbl bc_center">
            <svg class="icon" aria-hidden="true">
              <use xlink:href="#icon-gitee"></use>
            </svg>
            白菜吖</div>
        </div>
        <div class="bc-sm6 bc-md4 bc-lg6 bc-hide-xs">
          <div class="bc_box bc_mbl">
            <div class="bc_box bc_mbl">
              <p>如果您喜欢我们的网站，请将本站添加到收藏夹（快捷键<code>Ctrl+D</code>），并<a class="btn btn-green" href="https://jingyan.baidu.com/article/4dc40848868eba89d946f1c0.html" target="_blank">设为浏览器主页</a>，方便您的下次访问，感谢支持。<p>
            </div>
          </div>
        </div>
      </div>
      <div class="bc-row bc-space10">
      
      <?php
if ($conf['dh'] != 'false') {
    echo 
include "list.php";
}
?>
      
      
        <div class="bc-xs12 bc-sm7 bc-md7 bc-lg7">
          <div class="bc_box bc_mbl">
            <div class="bc-row">
              <h3 class="bc-xs12 bc_box"><svg class="icon" aria-hidden="true">
                  <use xlink:href="#icon-zhandian"></use>
                </svg>旗下站点</h3>
              <hr>
            </div>
            <div class="bc-row bc-space10" style="word-wrap:break-word;">
              <a href="/" class="bc-xs6 bc-sm4 bc-md4 bc-lg4">
                <div class="bc_a btn-orange bc_center"> <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-lianjie"></use>
                  </svg>白菜吖</div>
              </a>
              <a href="/" class="bc-xs6 bc-sm4 bc-md4 bc-lg4">
                <div class="bc_a btn-green bc_center"> <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-lianjie"></use>
                  </svg>白菜吖</div>
              </a>
              <a href="/" class="bc-xs6 bc-sm4 bc-md4 bc-lg4">
                <div class="bc_a btn-yellow bc_center"> <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-lianjie"></use>
                  </svg>白菜吖</div>
              </a>
              <a href="/" class="bc-xs6 bc-sm4 bc-md4 bc-lg4">
                <div class="bc_a btn-purple bc_center"> <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-lianjie"></use>
                  </svg>白菜吖</div>
              </a>
              <a href="/" class="bc-xs6 bc-sm4 bc-md4 bc-lg4">
                <div class="bc_a btn-yellow bc_center"> <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-lianjie"></use>
                  </svg>白菜吖</div>
              </a>
              <a href="/" class="bc-xs6 bc-sm4 bc-md4 bc-lg4">
                <div class="bc_a btn-blue bc_center"> <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-lianjie"></use>
                  </svg>白菜吖</div>
              </a>
            </div>
          </div>
        </div>
        <div class="bc-xs12 bc-sm5 bc-md5 bc-lg5">
          <div class="bc_box bc_mbl">
            <div class="bc-row">
              <h3 class="bc-xs12 bc_box"><svg class="icon" aria-hidden="true">
                  <use xlink:href="#icon-zhandian"></use>
                </svg>友情链接</h3>
              <hr>
            </div>
            <div class="bc-row bc-space10" style="word-wrap:break-word;">
              <a href="/" class="bc-xs6 bc-sm6 bc-md6 bc-lg6">
                <div class="bc_a btn-yellow bc_center"> <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-lianjie"></use>
                  </svg>白菜吖</div>
              </a>
              <a href="/" class="bc-xs6 bc-sm6 bc-md6 bc-lg6">
                <div class="bc_a btn-blue bc_center"> <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-lianjie"></use>
                  </svg>白菜吖</div>
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="bc-row bc-space10">
        <div class="bc-xs12">
          <div class="bc_box bc_mbl" id="bc_foot">
            Copyright © 2023 毛玻璃 白菜吖
            <span class="btn bc-hide-xs">收藏本站（快捷键<code>Ctrl+D</code>）</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Project -->
  
  <script src="<?php echo $templatepath;?>/main.js"></script>
  <script src="<?php echo $templatepath;?>/layui/layui.js"></script>
  <script src="<?php echo $templatepath;?>/iconfont.js"></script>
</body>

</html>