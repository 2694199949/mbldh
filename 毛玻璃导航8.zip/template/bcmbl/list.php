<?php
// 主题开发文档：https://doc.lylme.com/dev/theme
$html= array(
    'g1' => '
      <div class="bc-space10"><div class="bc-xs12 bc-sm6 bc-md6 bc-lg6"><div class="bc_box bc_mbl" > <div class="bc-row">
         ', //分组开始标签
    'g2' => ' 
              <h3 class="" id="group_{group_id}">{group_icon}<svg class="icon" aria-hidden="true">
                  <use xlink:href="#icon-zhandian"></use>
                </svg>{group_name}</h3>
              <hr>
            ',  //分组内容
    'g3' => '</div></div></div></div>',  //分组结束标签
    
    'l1' => '<a href="{link_url}" target="_blank"><span rel="nofollow" class="bc_a btn-d bc_mbl">',  //链接开始标签
    'l2' => '<span>{link_name}</span>',  //链接内容
    'l3' => '</span></a>',  //链接结束标签
);
lists($html);
?>